document.addEventListener('DOMContentLoaded', () => {
    const addGameForm = document.getElementById('add-game-form');
    const gameListContainer = document.getElementById('game-list');
    const searchBar = document.getElementById('search-bar');
    const storageKey = 'pss_games_repository';
    const body = document.body;

    // Admin login elements
    const ADMIN_PASSWORD = '675611223344Y'; // Contraseña simple
    const adminLoginBtn = document.getElementById('admin-login-btn');
    const passwordModal = document.getElementById('admin-password-modal');
    const closePasswordModalBtn = document.getElementById('close-password-modal-btn');
    const passwordForm = document.getElementById('admin-password-form');
    const passwordInput = document.getElementById('admin-password');

    // Edit Modal elements
    const editModal = document.getElementById('edit-game-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const editGameForm = document.getElementById('edit-game-form');
    const editGameIndexInput = document.getElementById('edit-game-index');
    const editGameTitleInput = document.getElementById('edit-game-title');
    const editGameImageInput = document.getElementById('edit-game-image');
    const editGameLinkInput = document.getElementById('edit-game-link');

    let isAdmin = false;

    let games = [];
    let filteredGames = [];

    const saveGames = () => {
        localStorage.setItem(storageKey, JSON.stringify(games));
    };

    const loadGames = () => {
        const storedGames = localStorage.getItem(storageKey);
        if (storedGames) {
            games = JSON.parse(storedGames);
        } else {
            // Ejemplo inicial si no hay juegos guardados
            games = [
                 {
                    title: "Dragon Ball Z: Shin Budokai 2",
                    image: "https://images.emulatorgames.net/playstation-portable/dragon-ball-z-shin-budokai-2.webp",
                    link: "#"
                },
                 {
                    title: "God of War: Ghost of Sparta",
                    image: "https://images.emulatorgames.net/playstation-portable/god-of-war-ghost-of-sparta.jpg",
                    link: "#"
                },
                {
                    title: "Grand Theft Auto: Vice City Stories",
                    image: "https://images.emulatorgames.net/playstation-portable/grand-theft-auto-vice-city-stories.jpg",
                    link: "#"
                },
                {
                    title: "Tekken 6",
                    image: "https://images.emulatorgames.net/playstation-portable/tekken-6.webp",
                    link: "#"
                },
                {
                    title: "Metal Gear Solid: Peace Walker",
                    image: "https://images.emulatorgames.net/playstation-portable/metal-gear-solid-peace-walker.jpg",
                    link: "#"
                },
                {
                    title: "Crisis Core: Final Fantasy VII",
                    image: "https://images.emulatorgames.net/playstation-portable/crisis-core-final-fantasy-vii.jpg",
                    link: "#"
                },
                {
                    title: "Monster Hunter Freedom Unite",
                    image: "https://images.emulatorgames.net/playstation-portable/monster-hunter-freedom-unite.jpg",
                    link: "#"
                }
            ];
        }
        filteredGames = [...games];
    };

    const renderGames = () => {
        gameListContainer.innerHTML = '';
        const gamesToRender = filteredGames;

        if (gamesToRender.length === 0) {
            gameListContainer.innerHTML = '<p>No se encontraron juegos. ¡Intenta con otra búsqueda o añade uno nuevo!</p>';
            return;
        }

        gamesToRender.forEach((game) => {
            // We need to find the original index to allow deletion from the filtered view
            const originalIndex = games.findIndex(g => g.title === game.title && g.image === game.image && g.link === game.link);
            const gameCard = document.createElement('div');
            gameCard.className = 'game-card';
            gameCard.innerHTML = `
                <img src="${game.image}" alt="Portada de ${game.title}" onerror="this.src='https://via.placeholder.com/250x300.png?text=No+Image'; this.onerror=null;">
                <div class="game-card-content">
                    <h3>${game.title}</h3>
                    <div class="game-card-actions">
                        <a href="${game.link}" class="btn" target="_blank" rel="noopener noreferrer">Descargar</a>
                    </div>
                </div>
                ${isAdmin ? `
                    <button class="edit-btn" data-index="${originalIndex}" title="Editar juego">&#9998;</button>
                    <button class="delete-btn" data-index="${originalIndex}" title="Eliminar juego">&times;</button>
                ` : ''}
            `;
            gameListContainer.appendChild(gameCard);
        });
    };
    
    const enableAdminMode = () => {
        isAdmin = true;
        body.classList.add('admin-view');
        adminLoginBtn.textContent = 'Salir de Admin';
        renderGames(); // Re-render to show buttons
    };

    const disableAdminMode = () => {
        isAdmin = false;
        body.classList.remove('admin-view');
        adminLoginBtn.textContent = 'Acceso Admin';
        renderGames(); // Re-render to hide buttons
    };

    const addGame = (event) => {
        event.preventDefault();
        const title = document.getElementById('game-title').value.trim();
        const image = document.getElementById('game-image').value.trim();
        const link = document.getElementById('game-link').value.trim();

        if (title && image && link) {
            games.unshift({ title, image, link }); // Añade al principio
            saveGames();
            filterGames(); // Re-applies the current filter
            addGameForm.reset();
        }
    };

    const deleteGame = (index) => {
        if (confirm(`¿Estás seguro de que quieres eliminar "${games[index].title}"?`)) {
            games.splice(index, 1);
            saveGames();
            filterGames(); // Re-applies the current filter
        }
    };

    const openEditModal = (index) => {
        const game = games[index];
        editGameIndexInput.value = index;
        editGameTitleInput.value = game.title;
        editGameImageInput.value = game.image;
        editGameLinkInput.value = game.link;
        editModal.style.display = 'block';
    };

    const closeEditModal = () => {
        editModal.style.display = 'none';
    };

    const saveGameChanges = (event) => {
        event.preventDefault();
        const index = editGameIndexInput.value;
        const newTitle = editGameTitleInput.value.trim();
        const newImage = editGameImageInput.value.trim();
        const newLink = editGameLinkInput.value.trim();

        if (index !== '' && newTitle && newImage && newLink) {
            games[index] = { title: newTitle, image: newImage, link: newLink };
            saveGames();
            filterGames();
            closeEditModal();
        }
    };
    
    const filterGames = () => {
        const searchTerm = searchBar.value.toLowerCase();
        filteredGames = games.filter(game => game.title.toLowerCase().includes(searchTerm));
        renderGames();
    };

    // Admin login logic
    adminLoginBtn.addEventListener('click', () => {
        if (isAdmin) {
            if (confirm('¿Estás seguro de que quieres salir del modo administrador?')) {
                disableAdminMode();
            }
        } else {
            passwordModal.style.display = 'block';
            passwordInput.focus();
        }
    });

    closePasswordModalBtn.addEventListener('click', () => {
        passwordModal.style.display = 'none';
        passwordInput.value = '';
    });
    
    passwordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (passwordInput.value === ADMIN_PASSWORD) {
            enableAdminMode();
            passwordModal.style.display = 'none';
            passwordInput.value = '';
        } else {
            alert('Contraseña incorrecta.');
            passwordInput.value = '';
            passwordInput.focus();
        }
    });

    // Event listener para añadir juego
    addGameForm.addEventListener('submit', addGame);

    // Event listener para acciones en la tarjeta de juego (delegación de eventos)
    gameListContainer.addEventListener('click', (event) => {
        if (!isAdmin) return;

        const target = event.target;
        if (target.classList.contains('delete-btn')) {
            const index = target.dataset.index;
            deleteGame(index);
        } else if (target.classList.contains('edit-btn')) {
            const index = target.dataset.index;
            openEditModal(index);
        }
    });

    // Event listeners para el modal
    closeModalBtn.addEventListener('click', closeEditModal);
    editGameForm.addEventListener('submit', saveGameChanges);
    window.addEventListener('click', (event) => {
        if (event.target === editModal) {
            closeEditModal();
        }
        if (event.target === passwordModal) {
            passwordModal.style.display = 'none';
            passwordInput.value = '';
        }
    });

    // Event listener para la barra de búsqueda
    searchBar.addEventListener('input', filterGames);

    // Carga y renderizado inicial
    loadGames();
    renderGames();
});